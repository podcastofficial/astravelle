-- Draft only; review and run as a proper migration before use.
CREATE TABLE IF NOT EXISTS app_users (
  id BIGSERIAL PRIMARY KEY,
  telegram_id TEXT UNIQUE,
  username TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS wallet_accounts (
  user_id BIGINT PRIMARY KEY REFERENCES app_users(id),
  available_micro_usdt BIGINT NOT NULL DEFAULT 0 CHECK (available_micro_usdt >= 0),
  reserved_micro_usdt BIGINT NOT NULL DEFAULT 0 CHECK (reserved_micro_usdt >= 0),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS wallet_transactions (
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT NOT NULL REFERENCES app_users(id),
  kind TEXT NOT NULL CHECK (kind IN ('deposit','withdrawal','reward','referral','adjustment')),
  status TEXT NOT NULL CHECK (status IN ('pending','approved','rejected','confirmed','failed')),
  amount_micro_usdt BIGINT NOT NULL CHECK (amount_micro_usdt > 0),
  idempotency_key TEXT UNIQUE,
  tx_hash TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE UNIQUE INDEX IF NOT EXISTS wallet_tx_hash_unique ON wallet_transactions(tx_hash) WHERE tx_hash IS NOT NULL;
