import { NextResponse } from 'next/server';
import { getSql } from '@/lib/db';
export const runtime = 'nodejs';
export async function GET() {
  try {
    const sql = getSql();
    await sql`SELECT 1 AS database_connected`;
    return NextResponse.json({ ok: true, database: 'connected' });
  } catch {
    return NextResponse.json({ ok: false, database: 'disconnected' }, { status: 503 });
  }
}
