import { NextResponse } from 'next/server';

// Intentionally disabled until server-side admin authentication and role checks exist.
export async function GET() {
  return NextResponse.json(
    { ok: false, error: 'Admin API is disabled until secure authentication and authorization are implemented.' },
    { status: 501 }
  );
}
