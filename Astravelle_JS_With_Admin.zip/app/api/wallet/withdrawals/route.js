import { NextResponse } from 'next/server';

// Deliberately disabled; this starter must not handle real funds.
export async function POST() {
  return NextResponse.json(
    { ok: false, error: 'Withdrawals are not enabled in this starter.' },
    { status: 501 }
  );
}
