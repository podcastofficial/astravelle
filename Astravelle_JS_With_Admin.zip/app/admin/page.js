'use client';
import { useState } from 'react';

const menu = ['Overview','Users','Deposits','Withdrawals','Tasks','Gift Codes','Referrals','Settings'];
const metrics = [
  ['TOTAL USERS','1,284','↗ Demo metrics'],['PENDING DEPOSITS','12','Awaiting review'],['PENDING WITHDRAWALS','7','Awaiting review'],['REWARDS PAID','$428.50','Demo amount']
];
export default function AdminPage() {
  const [active,setActive] = useState('Overview');
  const [notice,setNotice] = useState('');
  const [query,setQuery] = useState('');
  const [withdrawals,setWithdrawals] = useState([
    {id:'WD-1024',user:'demo_user_01',amount:'25.00 USDT',wallet:'0x1234…89ab',status:'Pending'},
    {id:'WD-1023',user:'demo_user_02',amount:'10.00 USDT',wallet:'0x7890…12cd',status:'Pending'},
    {id:'WD-1022',user:'demo_user_03',amount:'8.50 USDT',wallet:'0xabcd…4567',status:'Approved'}
  ]);
  const [users] = useState([
    {id:'10001',name:'demo_user_01',balance:'42.50',status:'Active'},
    {id:'10002',name:'demo_user_02',balance:'15.00',status:'Active'},
    {id:'10003',name:'demo_user_03',balance:'0.00',status:'Restricted'}
  ]);
  function action(id,status) {
    setWithdrawals(prev=>prev.map(w=>w.id===id?{...w,status}:w));
    setNotice(`${id}: demo status changed to ${status}. No real payment was sent.`);
  }
  return <main className="admin-layout">
    <aside className="admin-sidebar">
      <a className="brand admin-brand" href="/"><span className="brand-logo">A</span><span><b>ASTRAVELLE</b><small>ADMIN CONSOLE</small></span></a>
      <div className="admin-label">MANAGEMENT</div>
      {menu.map((s,i)=><button key={s} className={'nav '+(active===s?'selected':'')} onClick={()=>{setActive(s);setNotice('')}}><span>{['▦','♙','↓','↑','✦','▣','♧','⚙'][i]}</span>{s}{s==='Withdrawals'&&<i className="count">7</i>}</button>)}
      <div className="admin-side-bottom"><span className="demo-dot"/> Demo admin session<br/><small>Not authenticated</small><a href="/">← User dashboard</a></div>
    </aside>
    <section className="admin-content">
      <header className="header"><div><small>ADMINISTRATION / {active.toUpperCase()}</small><h1>{active}</h1></div><div className="admin-user"><span className="avatar">A</span><span><b>Admin Preview</b><small>UI DEMO ONLY</small></span></div></header>
      <div className="warning">⚠ <span><b>Demo mode:</b> figures are sample data. Approve/reject buttons only change this page's local preview; no funds or accounts are affected.</span></div>
      {notice&&<div className="notice">{notice}</div>}
      {active==='Overview'?<>
        <div className="metrics">{metrics.map(m=><article className="metric" key={m[0]}><small>{m[0]}</small><strong>{m[1]}</strong><span>{m[2]}</span></article>)}</div>
        <div className="admin-columns"><article className="panel"><div className="panel-title"><div><small>REQUIRES ATTENTION</small><h3>Withdrawal requests</h3></div><button className="text-btn" onClick={()=>setActive('Withdrawals')}>View all ↗</button></div>{withdrawals.filter(w=>w.status==='Pending').map(w=><div className="request" key={w.id}><div><b>{w.id}</b><small>{w.user} · {w.wallet}</small></div><strong>{w.amount}</strong><span className="pending">Pending</span></div>)}{withdrawals.every(w=>w.status!=='Pending')&&<p>No pending demo requests.</p>}</article>
        <article className="panel"><small>QUICK NAVIGATION</small><h3>Manage platform</h3>{menu.slice(1).map(s=><button className="quick" key={s} onClick={()=>setActive(s)}><b>↗</b><span><strong>{s}</strong><small>Open {s.toLowerCase()} workspace</small></span><i>→</i></button>)}</article></div>
      </>:active==='Withdrawals'?<article className="panel"><div className="panel-title"><div><small>MANUAL REVIEW QUEUE</small><h3>Withdrawal requests</h3></div><span className="pending">Demo data</span></div><div className="table-wrap"><table><thead><tr><th>REQUEST</th><th>USER</th><th>AMOUNT</th><th>WALLET</th><th>STATUS</th><th>ACTIONS</th></tr></thead><tbody>{withdrawals.map(w=><tr key={w.id}><td>{w.id}</td><td>{w.user}</td><td>{w.amount}</td><td>{w.wallet}</td><td><span className={w.status==='Pending'?'pending':w.status==='Approved'?'approved':'rejected'}>{w.status}</span></td><td>{w.status==='Pending'?<div className="row-actions"><button className="approve" onClick={()=>action(w.id,'Approved')}>Approve</button><button className="reject" onClick={()=>action(w.id,'Rejected')}>Reject</button></div>:<span className="muted">Reviewed</span>}</td></tr>)}</tbody></table></div><p className="footnote">Production workflow must verify admin permissions, reserve balance atomically, record audit logs and require a transaction hash after actual payout.</p></article>
      :active==='Users'?<article className="panel"><div className="panel-title"><div><small>ACCOUNT DIRECTORY</small><h3>Users</h3></div><input className="search" placeholder="Search demo users…" value={query} onChange={e=>setQuery(e.target.value)}/></div><div className="table-wrap"><table><thead><tr><th>USER ID</th><th>USERNAME</th><th>DEMO BALANCE</th><th>STATUS</th></tr></thead><tbody>{users.filter(u=>(u.name+u.id).toLowerCase().includes(query.toLowerCase())).map(u=><tr key={u.id}><td>{u.id}</td><td>{u.name}</td><td>${u.balance}</td><td><span className={u.status==='Active'?'approved':'rejected'}>{u.status}</span></td></tr>)}</tbody></table></div></article>
      :<article className="panel inner"><span className="chip">ADMIN WORKSPACE</span><h2>{active}</h2><p>{({Deposits:'Deposit review interface placeholder. On-chain transaction verification is not connected.',Tasks:'Create and manage task templates in a future secured backend.', 'Gift Codes':'Gift code creation and redemption history are not connected.',Referrals:'Referral statistics and commission ledger placeholder.',Settings:'Admin settings placeholder. Authentication and role-based access are not implemented.'})[active]||'This management section is a visual placeholder.'}</p><p className="muted">No real data is read or changed in this demo.</p></article>}
      <footer>© 2026 ASTRAVELLE <span>ADMIN PREVIEW · SECURE LOGIN NOT IMPLEMENTED</span></footer>
    </section>
  </main>;
}
